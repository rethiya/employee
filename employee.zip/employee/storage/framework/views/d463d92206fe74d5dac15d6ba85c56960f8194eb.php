<?php $__env->startSection('content'); ?>

 <div class="container mt-5">

        <!-- Success message -->
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('student.store')); ?>">

            <!-- CROSS Site Request Forgery Protection -->
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control <?php echo e($errors->has('name') ? 'error' : ''); ?>" name="name">

		        <!-- Error -->
		        <?php if($errors->has('name')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('name')); ?>

		        </div>
		        <?php endif; ?>
               
            </div>

            <div class="form-group">
                <label>Age</label>
                <input type="text" class="form-control <?php echo e($errors->has('age') ? 'error' : ''); ?>" name="age">

		        <?php if($errors->has('age')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('age')); ?>

		        </div>
		        <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Gender</label>
                 <input type="text" class="form-control <?php echo e($errors->has('gender') ? 'error' : ''); ?>" name="gender">

		        <?php if($errors->has('gender')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('gender')); ?>

		        </div>
		        <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Reporting Teacher</label>
                <select class="form-control" name="teacher">
                	<option>Maya</option>
                	<option>Meera</option>
                	<option>Lakshmi</option>
                </select>
            </div>

            

            <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block">
        </form>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/student-management/resources/views/students/create.blade.php ENDPATH**/ ?>