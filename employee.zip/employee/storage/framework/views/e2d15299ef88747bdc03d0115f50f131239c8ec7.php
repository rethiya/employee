<?php $__env->startSection('content'); ?>

        <h1>Students</h1>

        <br/>

        <a href = "<?php echo e(route('marks.create')); ?>"><button class = "btn btn-primary" type = "button">Add New Entry</button></a>

        <br/><br/>

        <table class = "table">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Maths</th>
                    <th>Science</th>
                    <th>History</th>
                    <th>Term</th>
                    <th>Total Marks</th>
                    <th>Created On</th>
                    <th>Action</th>
                    <th></th>
                </tr>
            </thead>
            <?php $i=1 ?>
            <tbody>
                <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

		                <tr class = "tableBody">
		                    <td><?php echo e($i); ?></td>
		                    <td><?php echo e($mark->student->name); ?></td>
		                    <td><?php echo e($mark->maths); ?></td>
		                    <td><?php echo e($mark->science); ?></td>
		                    <td><?php echo e($mark->history); ?></td>
                            <td><?php echo e($mark->term); ?></td>
                            <td><?php echo e($mark->total); ?></td>
                            <td><?php echo e($mark->created_at->format('M d,Y h:i A')); ?></td>
		                                                             
		                    <td class = "edit"><a class = "btn btn-success" href="<?php echo e(route('mark.edit', $mark->id)); ?>">Edit</a></td>
		                    <td class = "delete"><a class ="btn btn-danger" onclick = "return confirm('Are you sure?')" href="<?php echo e(route('mark.delete', $mark->id)); ?>">Delete</a></td>
		                </tr>  

	                <?php $i++; ?>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
              
            </tbody>

        </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/student-management/resources/views/marks/list.blade.php ENDPATH**/ ?>