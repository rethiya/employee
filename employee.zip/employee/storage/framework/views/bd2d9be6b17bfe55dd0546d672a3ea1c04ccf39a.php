<?php $__env->startSection('content'); ?>

        <h1>Students</h1>

        <br/>

        <a href = "<?php echo e(route('student.create')); ?>"><button class = "btn btn-primary" type = "button">Add New Entry</button></a>

        <br/><br/>

        <table class="table table-bordered yajra-datatable" id="employee-datatable">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Reporting Teacher</th>
                    <th></th>
                    <th>Action</th>
                   
                </tr>
            </thead>
          
            <tbody>
                               
              
            </tbody>

        </table>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/student-management/resources/views/students/view.blade.php ENDPATH**/ ?>