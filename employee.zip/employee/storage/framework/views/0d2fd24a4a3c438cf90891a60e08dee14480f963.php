<?php $__env->startSection('content'); ?>

 <div class="container mt-5">

        <!-- Success message -->
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('employee.store')); ?>">

            <!-- CROSS Site Request Forgery Protection -->
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control <?php echo e($errors->has('name') ? 'error' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>">

		        <!-- Error -->
		        <?php if($errors->has('name')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('name')); ?>

		        </div>
		        <?php endif; ?>
               
            </div>

            <div class="form-group">
                <label>Age</label>
                <input type="text" class="form-control <?php echo e($errors->has('age') ? 'error' : ''); ?>" name="age" value="<?php echo e(old('age')); ?>">

		        <?php if($errors->has('age')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('age')); ?>

		        </div>
		        <?php endif; ?>
            </div>

            <div class="form-group">
                <label>DOB</label>
                <input class="date form-control" type="text" name="dob" value="<?php echo e(old('dob')); ?>"">

                <?php if($errors->has('address')): ?>
                <div class="error alert alert-danger">
                    <?php echo e($errors->first('dob')); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Male<input type="radio" name="gender" value="M" checked></label>
                <label>Female<input type="radio" name="gender" value="F"></label>
            </div>


            <div class="form-group">
                <label>address</label>
                <textarea class="form-control" name="address"></textarea>

                <?php if($errors->has('address')): ?>
                <div class="error alert alert-danger">
                    <?php echo e($errors->first('address')); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Position</label>
                 <input type="text" class="form-control <?php echo e($errors->has('position') ? 'error' : ''); ?>" name="position" value="<?php echo e(old('position')); ?>">

                <?php if($errors->has('position')): ?>
                <div class="error alert alert-danger">
                    <?php echo e($errors->first('position')); ?>

                </div>
                <?php endif; ?>
            </div>

            <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block">
        </form>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/student-management/resources/views/employees/create.blade.php ENDPATH**/ ?>