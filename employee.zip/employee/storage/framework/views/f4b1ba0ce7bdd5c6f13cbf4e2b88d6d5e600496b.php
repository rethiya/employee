<?php $__env->startSection('content'); ?>

 <div class="container mt-5">

        <!-- Success message -->
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('marks.store')); ?>">

            <!-- CROSS Site Request Forgery Protection -->
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Student</label>
                <select class="form-control" name="student_id">
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label>Maths</label>
                <input type="text" class="form-control <?php echo e($errors->has('maths') ? 'error' : ''); ?>" name="maths">

		        <!-- Error -->
		        <?php if($errors->has('maths')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('maths')); ?>

		        </div>
		        <?php endif; ?>
               
            </div>

            <div class="form-group">
                <label>Science</label>
                <input type="text" class="form-control <?php echo e($errors->has('science') ? 'error' : ''); ?>" name="science">

		        <?php if($errors->has('science')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('science')); ?>

		        </div>
		        <?php endif; ?>
            </div>

            <div class="form-group">
                <label>History</label>
                 <input type="text" class="form-control <?php echo e($errors->has('history') ? 'error' : ''); ?>" name="history">

		        <?php if($errors->has('history')): ?>
		        <div class="error alert alert-danger">
		            <?php echo e($errors->first('history')); ?>

		        </div>
		        <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Term</label>
                <select class="form-control" name="term">
                    <option>One</option>
                    <option>Two</option>
                    <option>Three</option>
                    <option>Four</option>
                </select>
            </div>

            <div class="form-group">
                <label>Total Marks</label>
                 <input type="text" class="form-control <?php echo e($errors->has('total') ? 'error' : ''); ?>" name="total">

                <?php if($errors->has('total')): ?>
                <div class="error alert alert-danger">
                    <?php echo e($errors->first('total')); ?>

                </div>
                <?php endif; ?>
            </div>


            <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block">
        </form>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/student-management/resources/views/marks/create.blade.php ENDPATH**/ ?>